using System;
using System.Collections.Generic;

namespace gestiondenomina.DAL
{
    public class Gestiondenomina
    {
        // Propiedades
        public int Id { get; set; }
        public string Nombre { get; set; }
        public decimal SalarioBruto { get; set; }
        public DateTime FechaIngreso { get; set; }

        // Constantes de deducciones
        private const decimal AFP_PERCENT = 0.0287m; // 2.87%
        private const decimal ARS_PERCENT = 0.0304m; // 3.04%
        private const decimal ISR_PERCENT = 0.02m;   // 2% (opcional)

        // Cálculos de deducciones
        public decimal AFP
        {
            get { return SalarioBruto * AFP_PERCENT; }
        }

        public decimal ARS
        {
            get { return SalarioBruto * ARS_PERCENT; }
        }

        public decimal ISR
        {
            get { return SalarioBruto * ISR_PERCENT; }
        }

        public decimal Deducciones
        {
            get { return AFP + ARS + ISR; }
        }

        public decimal SalarioNeto
        {
            get { return SalarioBruto - Deducciones; }
        }

        public decimal totalpagarporlaempresa
        {
            get { return SalarioNeto; }
        }
        // Constructor
            public Gestiondenomina()
            {
                Id = 0;
                Nombre = string.Empty;
                SalarioBruto = 0m;
                FechaIngreso = DateTime.MinValue;
            }

            public Gestiondenomina(int id, string nombre, decimal salarioBruto, DateTime fechaIngreso)
            {
                Id = id;
                Nombre = nombre;
                SalarioBruto = salarioBruto;
                FechaIngreso = fechaIngreso;
            }

        // Metodo para mostrar detalles del empleado
        public void MostrarDetalles()
        {
            Console.WriteLine($"ID: {Id}, Nombre: {Nombre}, Salario Bruto: {SalarioBruto:C}, Deducciones: {Deducciones:C}, Salario Neto: {SalarioNeto:C}, Fecha de Ingreso: {FechaIngreso.ToShortDateString()}");
        }
    }
}