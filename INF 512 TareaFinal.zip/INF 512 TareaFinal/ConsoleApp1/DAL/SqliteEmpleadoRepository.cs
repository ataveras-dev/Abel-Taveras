using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

namespace gestiondenomina.DAL
{
    public class SqliteEmpleadoRepository : IEmpleadoRepository
    {
        private readonly string _connectionString;

        public SqliteEmpleadoRepository(string databasePath = "Data Source=nomina.db")
        {
            _connectionString = databasePath;
            CrearTablaSiNoExiste();
        }

        public void CrearTablaSiNoExiste()
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"CREATE TABLE IF NOT EXISTS Empleados (
                Id INTEGER PRIMARY KEY,
                Nombre TEXT NOT NULL,
                SalarioBruto REAL NOT NULL,
                FechaIngreso TEXT NOT NULL
            );";
            cmd.ExecuteNonQuery();
        }

        public void Add(Gestiondenomina empleado)
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO Empleados (Id, Nombre, SalarioBruto, FechaIngreso) VALUES (@id, @nombre, @salario, @fecha);";
            cmd.Parameters.AddWithValue("@id", empleado.Id);
            cmd.Parameters.AddWithValue("@nombre", empleado.Nombre);
            cmd.Parameters.AddWithValue("@salario", empleado.SalarioBruto);
            cmd.Parameters.AddWithValue("@fecha", empleado.FechaIngreso.ToString("o"));
            cmd.ExecuteNonQuery();
        }

        public Gestiondenomina? GetById(int id)
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, Nombre, SalarioBruto, FechaIngreso FROM Empleados WHERE Id = @id;";
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                var emp = new Gestiondenomina
                {
                    Id = reader.GetInt32(0),
                    Nombre = reader.GetString(1),
                    SalarioBruto = reader.GetDecimal(2),
                    FechaIngreso = DateTime.Parse(reader.GetString(3))
                };
                return emp;
            }
            return null;
        }

        public List<Gestiondenomina> GetAll()
        {
            var list = new List<Gestiondenomina>();
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, Nombre, SalarioBruto, FechaIngreso FROM Empleados ORDER BY Id;";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var emp = new Gestiondenomina
                {
                    Id = reader.GetInt32(0),
                    Nombre = reader.GetString(1),
                    SalarioBruto = reader.GetDecimal(2),
                    FechaIngreso = DateTime.Parse(reader.GetString(3))
                };
                list.Add(emp);
            }
            return list;
        }

        public void Update(Gestiondenomina empleado)
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Empleados SET Nombre=@nombre, SalarioBruto=@salario, FechaIngreso=@fecha WHERE Id=@id;";
            cmd.Parameters.AddWithValue("@id", empleado.Id);
            cmd.Parameters.AddWithValue("@nombre", empleado.Nombre);
            cmd.Parameters.AddWithValue("@salario", empleado.SalarioBruto);
            cmd.Parameters.AddWithValue("@fecha", empleado.FechaIngreso.ToString("o"));
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM Empleados WHERE Id=@id;";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }
    }
}
