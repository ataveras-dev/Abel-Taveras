using System;
using System.Collections.Generic;

namespace gestiondenomina.DAL
{
    public interface IEmpleadoRepository
    {
        void CrearTablaSiNoExiste();
        void Add(Gestiondenomina empleado);
        Gestiondenomina? GetById(int id);
        List<Gestiondenomina> GetAll();
        void Update(Gestiondenomina empleado);
        void Delete(int id);
    }
}
