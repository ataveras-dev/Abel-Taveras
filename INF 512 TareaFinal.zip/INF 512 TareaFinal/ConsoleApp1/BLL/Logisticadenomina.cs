using System;
using System.Collections.Generic;

using gestiondenomina.DAL;
namespace gestiondenomina.BLL
{
    public class Logisticadenomina
    {
        private List<Gestiondenomina> empleados;

        public Logisticadenomina()
        {
            empleados = new List<Gestiondenomina>();
        }

        public void AgregarEmpleado(Gestiondenomina empleado)
        {
            empleados.Add(empleado);
        }

        public void MostrarTodosLosEmpleados()
        {
            foreach (var empleado in empleados)
            {
                empleado.MostrarDetalles();
            }
        }

        public decimal CalcularCostoTotalDeNomina()
        {
            decimal total = 0;
            foreach (var empleado in empleados)
            {
                total += empleado.totalpagarporlaempresa;
            }
            return total;
        }
    }
}